//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

var arr = [8,0,1,2,3,4,5,6]
//var arr = ["storia", "arte"]

sort(insertion: &arr)
print(arr)

reverseSort(insertion: &arr)