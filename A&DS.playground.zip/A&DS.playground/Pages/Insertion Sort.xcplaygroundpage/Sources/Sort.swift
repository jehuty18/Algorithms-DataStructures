import Foundation
import UIKit

public func sort<T: Comparable>(insertion arr: inout [T]){
    var key: T
    var i: Int
    
    for j in 1...arr.count-1{
        do{
            key = arr[j]
            i = j-1
            while i >= 0 && arr[i] > key {
                arr[i+1] = arr[i]
                i = i - 1
            }
            arr[i+1] = key
        }
    }
}

public func reverseSort<T: Comparable>(insertion array: inout [T]){
    sort(insertion: &array)
    array.reverse()
}
