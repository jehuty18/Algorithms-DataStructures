import Foundation

public struct Stack<T: Comparable>{
    
    fileprivate var array = [T]()
    fileprivate var maxElem: Int = Int.max
    
    public init(){}
    public init(maxElem n: Int){
        self.maxElem = n
    }
    
    public func isEmpty() -> Bool{
        return array.isEmpty
    }
    
    public func isFull() -> Bool{
        if array.count == maxElem - 1{
            return true
        }
        return false
    }
    
    public func head() -> T{
        return array[0]
    }
    
    mutating public func push(_ element: T){
        if !self.isFull(){
            array.append(element)
        }
    }
    
    mutating public func pop() -> T?{
        if !self.isEmpty(){
            return array.popLast()!
        }
        return nil
    }
    
    private func reverse() -> [T]{
        return array.reversed()
    }
    
    //func print
    //func search
}

public struct ArrayIterator<T: Comparable>: IteratorProtocol{
    private var currentElement: [T]
    
    public init(elements: [T]){
        self.currentElement = elements
    }
    
    public mutating func next() -> T?{
        if !self.currentElement.isEmpty{
            return self.currentElement.popLast()
        }
        return nil
    }
}

extension Stack: Sequence{
    public func makeIterator() -> ArrayIterator<T> {
        return ArrayIterator<T>(elements: self.array)
    }
}
