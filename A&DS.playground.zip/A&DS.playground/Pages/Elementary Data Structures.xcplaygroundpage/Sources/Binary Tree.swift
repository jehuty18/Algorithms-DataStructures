import Foundation

//traditional way
public class TreeNode<T: Comparable>{
    public fileprivate(set) var value: T
    public fileprivate(set) var leftChild: TreeNode<T>?
    public fileprivate(set) var rightChild: TreeNode<T>?
    
    public init(_ value: T){
        self.value = value
    }
    
    public func setLeftChild(_ value: T){
        self.leftChild = TreeNode(value)
    }
    
    public func setRightChild(_ value: T){
        self.rightChild = TreeNode(value)
    }
}

public class BinTree<T: Comparable>{
    public fileprivate(set) var root: TreeNode<T>?
    
    public init(_ value: T){
        self.root = TreeNode(value)
    }
}

//using enumeration
public enum BinaryTree<T: Comparable>{
    case empty
    indirect case node(BinaryTree, T, BinaryTree)
    
    public var count: Int{
        switch self {
        case let .node(left, _ , right):
            return left.count + 1 + right.count
        case .empty:
            return 0
        }
    }
}

extension BinaryTree: CustomStringConvertible {
    public var description: String {
        switch self {
        case let .node(left, value, right):
            return "value: \(value), left = [" + left.description + "], right = [" + right.description + "]"
        case .empty:
            return ""
        }
    }
}
