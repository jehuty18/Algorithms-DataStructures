import Foundation

public struct Queue<T: Comparable>{
    
    private var array = [T]()
    private var maxElem = Int.max
    
    public init(){}
    public init(maxElem n: Int){
        self.maxElem = n
    }
    
    public func isEmpty() -> Bool{
        return array.isEmpty
    }
    
    public func isFull() -> Bool{
        if self.array.count == maxElem-1{
            return true
        }
        return false
    }
    
    public mutating func enqueue(_ element: T){
        if !self.isFull(){
            self.array.append(element)
        }
    }
    
    public mutating func dequeue() -> T?{
        guard !self.isEmpty(), let elem = self.array.first
            else{
                return nil
        }
        self.array.remove(at: 0)
        return elem
    }
    
    public func head() -> T?{
        
        guard !self.isEmpty(), let firstElem = self.array.first
            else{
                return nil
        }
        return firstElem
    }
    
    public func tail() -> T?{
        
        guard !self.isEmpty(), let lastElem = self.array.last
            else{
                return nil
        }
        return lastElem
    }
    
    //func print
    //func search
}
