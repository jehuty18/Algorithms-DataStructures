import Foundation

public class Node<T: Comparable>{
    
    public fileprivate(set) var value: T?
    public fileprivate(set) var next: Node<T>?
    fileprivate weak var prev: Node<T>?
    
    fileprivate init(){}
    
    fileprivate init(_ value: T){
        self.value = value
    }
}

public class List<T: Comparable>{
    
    fileprivate var head: Node<T>?
    fileprivate var tail: Node<T>?
    public fileprivate(set) var itemCount: Int = 0
    
    public init(){}
    
    public func isEmpty() -> Bool{
        return head == nil
    }
    
    public func first() -> T{
        return head as! T
    }
    
    public func append(newItem value: T) {
        
        let newNode = Node(value)
        if let tailNode = tail{
            newNode.prev = tailNode
            tailNode.next = newNode
        }
        else {
            head = newNode
        }
        tail = newNode
        self.itemCount += 1
    }
    
    public func insert(newItem value: T, at index: Int = 0){
        
        precondition(index >= 0 && index <= self.itemCount)
        
        var i = index - 1
        var iNode = head
        let newNode = Node(value)
                
        if iNode != nil{
            //inserimento in testa
            if index == 0{
                self.headingInsert(newNode)
                self.itemCount += 1
            }
            else{
                while i > 0{
                    i -= 1
                    iNode = iNode?.next
                }
                //inserimento in un punto della catena
                if iNode?.next != nil{
                    self.insertingInside(newNode, iNode)
                    self.itemCount += 1
                }
                //inserimento in coda
                else{
                    self.append(newItem: value)
                }
            }
        }
        else{
            head = newNode
            self.itemCount += 1
        }
        
    }
    
    fileprivate func headingInsert(_ newNode: Node<T>){
        if let headNode = head{
            newNode.next = headNode
            headNode.prev = newNode
        }
        else{
            head = newNode
        }
        head = newNode
    }
    
    fileprivate func insertingInside(_ newNode: Node<T>, _ iNode: Node<T>?){
        
        var iNextNode: Node<T>

        iNextNode = (iNode?.next)!
        
        iNode?.next = newNode
        iNextNode.prev = newNode
        newNode.prev = iNode
        newNode.next = iNextNode
    }
    
    public func searchFor(value i: T) -> Bool{
        
        var iNode = head
        while iNode != nil{
            if iNode?.value == i{
                return true
            }
            iNode = iNode?.next
        }
        return false
    }
    
    public func nodeAt(_ index: Int) -> Node<T>?{
        
        precondition(index >= 0 && index < self.itemCount, "Index out of buonds")
        if index >= 0{
            var iNode = head
            var i = index
            
            while iNode != nil{
                if i == 0{
                    return iNode
                }
                i -= 1
                iNode = iNode?.next
            }
        }
        return nil
    }
    
    public func searchForItemAndIndex(ofValue value: T) -> (iNode: Node<T>?,index: Int?){
        var iNode = head
        var i = 0
        while iNode != nil{
            if iNode?.value == value{
                return (iNode,i)
            }
            iNode = iNode?.next
            i += 1
        }
        return (nil,nil)
    }
}

extension List{
    
    public func removeNode(_ value: T){
        precondition(self.searchFor(value: value), "No element of value: \(value)")
        
        let iNode = self.searchForItemAndIndex(ofValue: value).iNode
        if iNode === head && iNode === tail{
            head = nil
            tail = nil
        }
        else if iNode === head{
            head = iNode?.next
        }
        else if iNode === tail{
            tail = iNode?.prev
        }
        else{
            iNode?.prev?.next = iNode?.next
            iNode?.next?.prev = iNode?.prev
        }
        self.itemCount -= 1
    }
    
    public func removeNode(atIndex index: Int){
        precondition(index >= 0 && index <= self.itemCount)
        if let iNode = self.nodeAt(index){
            self.removeNode(iNode.value!)
        }
    }
}

extension List: CustomStringConvertible{
    public var description: String{
        var text = "["
        var node = head
        
        while node != nil{
            text += "\((node!.value)!)"
            node = node!.next
            if node != nil{
                text += ", "
            }
        }
        return text + "]"
    }
}

public struct LinkedListIterator<T: Comparable>: IteratorProtocol{
    public typealias Element = Node<T>
    
    public var currentNode: Element?
    public init(startNode: Element?){
        currentNode = startNode
    }
    public mutating func next() -> LinkedListIterator.Element?{
        let node = currentNode
        currentNode = currentNode?.next
        
        return node
    }
}

extension List: Sequence{
    public typealias Iterator = LinkedListIterator<T>
    public func makeIterator() -> LinkedListIterator<T> {
        return LinkedListIterator(startNode: head)
    }
}



