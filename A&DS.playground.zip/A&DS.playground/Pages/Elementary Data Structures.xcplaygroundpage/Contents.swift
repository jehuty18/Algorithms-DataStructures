//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//stack operations
var stack = Stack<Double>()
stack.push(2.3)
stack.push(1.5)
stack.push(4.5)
var x = stack.pop()

//queue operations
var queue = Queue<Double>()
queue.enqueue(2.3)
queue.enqueue(1.5)
queue.enqueue(2.1)
print(queue)

//double-point list
var a = List<Double>()
a.append(newItem: 2.5)
a.append(newItem: 1.3)
a.append(newItem: 5.2)
a.insert(newItem: 1.4)
print("list",a.description)
a.append(newItem: 9)
print("list",a.description)
a.insert(newItem: 4, at: 0)
print("list",a.description)
a.removeNode(5.2)
print("list",a.description)


//traditional tree
var tradRoot = BinTree(5)
print(tradRoot)

//enum tree
let letterA = BinaryTree.node(.empty, 2, .empty)
let root = BinaryTree.node(letterA, 1, .empty)
print(root)
