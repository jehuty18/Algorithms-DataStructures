import Foundation

public func sort<T: Comparable>(heapsort array: inout [T]){
    
    var heapsize: Int = array.count-1
    
    buildHeap(&array, arraySize: &heapsize)
    for i in stride(from: array.count-1, to: 0, by: -1){
        swap(&array[0], &array[i])
        heapsize -= 1
        heapify(heap: &array, 0, &heapsize)
    }
}

private func heapify<T: Comparable>(heap array: inout [T],_ index: Int, _ heapsize: inout Int){
    let left = leftNodeIndex(index)
    let right = rightNodeIndex(index)
    var greater: Int
    
    if left <= heapsize && array[left] > array[index]{
        greater = left
    }
    else{
        greater = index
    }
    
    if right <= heapsize && array[right] > array[greater]{
        greater = right
    }
    
    if greater != index{
        swap(&array[index], &array[greater])
        heapify(heap: &array, greater, &heapsize)
    }
}


private func buildHeap<T: Comparable>(_ array: inout [T], arraySize heapsize: inout Int){
    for i in stride(from: (array.count-1)/2, to: -1, by: -1){
        heapify(heap: &array, i, &heapsize)
    }
}

public func leftNodeIndex(_ index: Int) -> Int{
    return 2*index+1
}
public func rightNodeIndex(_ index: Int) -> Int{
    return 2*index+2
}
public func fatherNodeIndex(_ index: Int) -> Int{
    return index/2
}

public func isHeap<T: Comparable>(arrayHeap array: inout [T]) -> Bool{
    
    var isHeap: Bool = true
    let size = array.count-1
    
    for i in 0...size/2{
        let left = leftNodeIndex(i)
        let right = rightNodeIndex(i)
        if left <= size && right <= size{
            if array[left] > array[i] || array[right] > array[i]{
                isHeap = false
                return isHeap
            }
        }
    }
    return isHeap
}

public func reverseSort<T: Comparable>(heapsort array: inout [T]){
    sort(heapsort: &array)
    array.reverse()
}
