//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

var arr = [8,2,0,1,3,9,5,6,4]
//var arr = ["storia","calcio","arte","base"]

var size = arr.count-1
sort(heapsort: &arr)
print(arr)

reverseSort(heapsort: &arr)

//buildHeap(&arr, arraySize: &size)
//print(arr)
//print(isHeap(arrayHeap: &arr))
