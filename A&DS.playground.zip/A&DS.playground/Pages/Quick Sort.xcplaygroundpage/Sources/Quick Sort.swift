import Foundation

public func sort<T: Comparable>(quicksort array: inout [T]){
    let arraySize = array.count
    quicksort(&array, p: 0, r: arraySize)
}

private func quicksort<T: Comparable>(_ array: inout [T], p indexP: Int, r indexR: Int){

    if indexP < indexR{
        let q = partition(&array, p: indexP, r: indexR)
        quicksort(&array, p: indexP, r: q)
        quicksort(&array, p: q+1, r: indexR)
    }
}

private func partition<T: Comparable>(_ array: inout [T], p indexP: Int, r indexR: Int) -> Int{
    
    let pivot = array[indexP]
    var i = indexP
    var j: Int = indexP + 1
    
    while j < indexR{
        if array[j] <= pivot{
            i += 1
            swap(&array[i], &array[j])
        }
        j += 1
    }
    swap(&array[i], &array[indexP])
    return i
}

public func reverseSort<T: Comparable>(quicksort array: inout [T]){
    sort(quicksort: &array)
    array.reverse()
}
