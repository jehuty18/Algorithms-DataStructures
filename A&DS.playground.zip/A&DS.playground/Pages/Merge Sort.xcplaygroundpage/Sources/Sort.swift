import Foundation
import UIKit

public func sort<T: Comparable>(merge arr: inout [T]){
    
    let start = arr.startIndex
    let end = arr.endIndex-1
    _ = mergesort(&arr, start, end)
}

private func mergesort<T: Comparable>(_ arr: inout [T], _ left: Int, _ right: Int) -> [T]{
    
    if left < right{
        let center: Int = (left + right)/2
        _ = mergesort(&arr, left, center)
        _ = mergesort(&arr, center+1, right)
        _ = merge(&arr, left, center, right)
    }
    return arr
}

private func merge<T: Comparable>(_ arr: inout [T], _ left: Int, _ center: Int, _ right: Int) -> [T]{
    
    var supportArray: [T] = Array<Any>(repeating: arr[left], count: arr.count) as! [T]
    var tempI: Int = 0
    var tempJ: Int = 0
    
    for i in stride(from: center+1, to: left, by: -1){
        supportArray[i-1] = arr[i-1]
        tempI = i - 1
    }
    for j in center...right-1{
        supportArray[right+center-j] = arr[j+1]
        tempJ = j + 1
    }
    
    for k in left...right{
        if supportArray[tempJ] < supportArray[tempI]{
            arr[k] = supportArray[tempJ]
            tempJ -= 1
        }
        else {
            arr[k] = supportArray[tempI]
            tempI += 1
        }
    }
    
    return arr
}

public func reverseSort<T: Comparable>(merge array: inout [T]){
    sort(merge: &array)
    array.reverse()
}
