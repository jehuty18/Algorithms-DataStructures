//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var arr = [3,4,7,9,2,1,8,6,5,0]
//var arr = ["storia","calcio","arte","base"]
//var arr = [2.4,2.2,1.3,5.6]

sort(merge: &arr)
print(arr)
