//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

var arr = [8,2,0,1,3,5,6,4]
//var arr = ["storia","calcio","arte","base"]

sort(selection: &arr)
print(arr)

reverseSort(selection: &arr)