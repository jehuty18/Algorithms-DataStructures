import Foundation

public func sort<T: Comparable>(selection array: inout [T]){
    
    for i in stride(from: array.count-1, to: 0, by: -1){
        do{
            let max = findmax(&array, i)
            swap(&array[max], &array[i])
        }
    }
}

private func findmax<T: Comparable>(_ array: inout [T], _ index: Int) -> Int{
    
    var max = 0
    
    for i in 1...index{
        if array[max] < array[i]{
            max = i
        }
    }
    return max
}

public func reverseSort<T: Comparable>(selection array: inout [T]){
    sort(selection: &array)
    array.reverse()
}
