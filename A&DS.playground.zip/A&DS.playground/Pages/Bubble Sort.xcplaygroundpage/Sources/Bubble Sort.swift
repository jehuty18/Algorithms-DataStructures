import Foundation

public func sort<T: Comparable>(bubble array: inout [T]){
    var last: Int
    var higher: Int = array.count
    
    while higher > 0{
        last = -1
        for i in 1...higher-1{
            if array[i-1] > array[i]{
                swap(&array[i-1], &array[i])
                last = i
            }
        }
        higher = last
    }
}

public func reverseSort<T: Comparable>(bubble array: inout [T]){
    sort(bubble: &array)
    array.reverse()
}
